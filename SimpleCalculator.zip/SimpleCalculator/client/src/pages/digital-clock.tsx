import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Moon, Sun } from 'lucide-react';

// Arabic days and months
const AR_DAYS = ["الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"];
const AR_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
];

export default function DigitalClock() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [use24Hour, setUse24Hour] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [blinkColon, setBlinkColon] = useState(true);

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Blink colon every second
  useEffect(() => {
    const blinkTimer = setInterval(() => {
      setBlinkColon(prev => !prev);
    }, 1000);

    return () => clearInterval(blinkTimer);
  }, []);

  // Format time
  const formatTime = (date: Date) => {
    let hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    let ampm = '';

    if (!use24Hour) {
      ampm = hours >= 12 ? 'م' : 'ص';
      hours = hours % 12;
      hours = hours ? hours : 12; // 0 should be 12
    }

    const timeString = `${hours.toString().padStart(2, '0')}${blinkColon ? ':' : ' '}${minutes.toString().padStart(2, '0')}${blinkColon ? ':' : ' '}${seconds.toString().padStart(2, '0')}`;
    
    return { timeString, ampm };
  };

  // Format date in Arabic
  const formatArabicDate = (date: Date) => {
    const dayName = AR_DAYS[date.getDay() === 0 ? 6 : date.getDay() - 1]; // Adjust for Monday = 0
    const day = date.getDate();
    const month = AR_MONTHS[date.getMonth()];
    const year = date.getFullYear();
    
    return `${dayName}، ${day} ${month} ${year}`;
  };

  const { timeString, ampm } = formatTime(currentTime);
  const arabicDate = formatArabicDate(currentTime);

  const themeClasses = isDarkMode 
    ? 'bg-slate-900 text-white' 
    : 'bg-slate-50 text-slate-900';

  const cardClasses = isDarkMode 
    ? 'bg-slate-800 border-slate-700' 
    : 'bg-white border-slate-200';

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 transition-colors duration-300 ${themeClasses}`}>
      <Card className={`w-full max-w-2xl shadow-2xl transition-colors duration-300 ${cardClasses}`}>
        <CardContent className="p-8 text-center">
          {/* Time Display */}
          <div className="mb-6">
            <div className="text-6xl md:text-8xl font-bold font-mono tracking-wider mb-2">
              {timeString}
              {!use24Hour && (
                <span className="text-2xl md:text-3xl ml-4 opacity-80">
                  {ampm}
                </span>
              )}
            </div>
          </div>

          {/* Date Display */}
          <div className="mb-8">
            <p className="text-xl md:text-2xl opacity-80 font-medium" dir="rtl">
              {arabicDate}
            </p>
          </div>

          {/* Controls */}
          <div className="space-y-4">
            <div className="flex items-center justify-center space-x-8 rtl:space-x-reverse">
              {/* 24 Hour Toggle */}
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Switch
                  id="24hour"
                  checked={use24Hour}
                  onCheckedChange={setUse24Hour}
                  data-testid="toggle-24hour"
                />
                <Label htmlFor="24hour" className="text-sm font-medium">
                  نظام 24 ساعة
                </Label>
              </div>

              {/* Theme Toggle */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="flex items-center space-x-2"
                data-testid="toggle-theme"
              >
                {isDarkMode ? (
                  <>
                    <Sun className="h-4 w-4" />
                    <span>الوضع النهاري</span>
                  </>
                ) : (
                  <>
                    <Moon className="h-4 w-4" />
                    <span>الوضع الليلي</span>
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}