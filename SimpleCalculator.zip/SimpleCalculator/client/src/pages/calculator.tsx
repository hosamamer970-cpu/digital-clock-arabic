import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function Calculator() {
  const [currentInput, setCurrentInput] = useState("");
  const [operation, setOperation] = useState<string | null>(null);
  const [previousInput, setPreviousInput] = useState("");
  const [shouldResetDisplay, setShouldResetDisplay] = useState(false);
  const [showError, setShowError] = useState(false);

  const updateDisplay = useCallback(() => {
    return currentInput || "0";
  }, [currentInput]);

  const handleNumber = useCallback((num: string) => {
    if (shouldResetDisplay) {
      setCurrentInput(num);
      setShouldResetDisplay(false);
    } else {
      setCurrentInput(prev => prev + num);
    }
    setShowError(false);
  }, [shouldResetDisplay]);

  const handleOperation = useCallback((op: string) => {
    if (currentInput === "") return;
    
    if (previousInput !== "" && operation !== null && !shouldResetDisplay) {
      handleEquals();
    }
    
    setOperation(op);
    setPreviousInput(currentInput);
    setShouldResetDisplay(true);
  }, [currentInput, previousInput, operation, shouldResetDisplay]);

  const handleDecimal = useCallback(() => {
    if (shouldResetDisplay) {
      setCurrentInput("0.");
      setShouldResetDisplay(false);
    } else if (currentInput.indexOf(".") === -1) {
      setCurrentInput(prev => prev + ".");
    }
    setShowError(false);
  }, [shouldResetDisplay, currentInput]);

  const handleEquals = useCallback(() => {
    if (operation === null || previousInput === "" || currentInput === "") return;

    let result: number;
    const prev = parseFloat(previousInput);
    const current = parseFloat(currentInput);

    try {
      switch (operation) {
        case "+":
          result = prev + current;
          break;
        case "-":
          result = prev - current;
          break;
        case "*":
          result = prev * current;
          break;
        case "/":
          if (current === 0) throw new Error("Division by zero");
          result = prev / current;
          break;
        default:
          return;
      }

      setCurrentInput(result.toString());
      setOperation(null);
      setPreviousInput("");
      setShouldResetDisplay(true);
      setShowError(false);
    } catch (error) {
      setCurrentInput("");
      setShowError(true);
      setTimeout(() => setShowError(false), 2000);
    }
  }, [operation, previousInput, currentInput]);

  const handleClear = useCallback(() => {
    setCurrentInput("");
    setOperation(null);
    setPreviousInput("");
    setShouldResetDisplay(false);
    setShowError(false);
  }, []);

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const key = event.key;
      
      if (key >= "0" && key <= "9") {
        handleNumber(key);
      } else if (key === ".") {
        handleDecimal();
      } else if (["+", "-", "*", "/"].includes(key)) {
        handleOperation(key);
      } else if (key === "Enter" || key === "=") {
        event.preventDefault();
        handleEquals();
      } else if (key === "Escape" || key === "c" || key === "C") {
        handleClear();
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleNumber, handleDecimal, handleOperation, handleEquals, handleClear]);

  const buttonVariants = {
    number: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    operation: "bg-accent text-accent-foreground hover:bg-accent/80",
    equals: "bg-primary text-primary-foreground hover:bg-primary/90",
    clear: "bg-destructive text-destructive-foreground hover:bg-destructive/90"
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-muted to-accent" dir="rtl">
      <div className="calculator-container w-full max-w-md mx-4">
        <Card className="bg-card rounded-xl shadow-2xl border border-border overflow-hidden">
          {/* Header */}
          <div className="bg-primary px-6 py-4">
            <h1 className="text-primary-foreground text-xl font-semibold text-center">
آلة حاسبة ذكية
            </h1>
          </div>

          {/* Calculator Body */}
          <div className="p-6">
            {/* Display */}
            <div className="mb-6">
              <div className="bg-muted rounded-lg border-2 border-border p-4 min-h-[80px] flex items-center">
                <input
                  type="text"
                  className="w-full bg-transparent text-right text-3xl font-mono font-semibold text-foreground placeholder-muted-foreground border-none outline-none display"
                  placeholder="0"
                  value={showError ? "خطأ" : updateDisplay()}
                  readOnly
                  data-testid="display-input"
                />
              </div>
            </div>

            {/* Button Grid */}
            <div className="grid grid-cols-4 gap-3">
              {/* Row 1: Clear and Operations */}
              <Button
                className={`calculator-button col-span-2 ${buttonVariants.clear} rounded-lg h-14 text-lg font-semibold`}
                onClick={handleClear}
                data-testid="button-clear"
              >
                مسح (C)
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.operation} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleOperation("/")}
                data-testid="button-divide"
              >
                ÷
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.operation} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleOperation("*")}
                data-testid="button-multiply"
              >
                ×
              </Button>

              {/* Row 2: Numbers 7-9 and subtraction */}
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("7")}
                data-testid="button-7"
              >
                7
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("8")}
                data-testid="button-8"
              >
                8
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("9")}
                data-testid="button-9"
              >
                9
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.operation} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleOperation("-")}
                data-testid="button-subtract"
              >
                −
              </Button>

              {/* Row 3: Numbers 4-6 and addition */}
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("4")}
                data-testid="button-4"
              >
                4
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("5")}
                data-testid="button-5"
              >
                5
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("6")}
                data-testid="button-6"
              >
                6
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.operation} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleOperation("+")}
                data-testid="button-add"
              >
                +
              </Button>

              {/* Row 4: Numbers 1-3 and equals */}
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("1")}
                data-testid="button-1"
              >
                1
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("2")}
                data-testid="button-2"
              >
                2
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("3")}
                data-testid="button-3"
              >
                3
              </Button>
              <Button
                className={`calculator-button row-span-2 ${buttonVariants.equals} rounded-lg text-xl font-semibold flex items-center justify-center`}
                onClick={handleEquals}
                data-testid="button-equals"
              >
                =
              </Button>

              {/* Row 5: 0, decimal point */}
              <Button
                className={`calculator-button col-span-2 ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={() => handleNumber("0")}
                data-testid="button-0"
              >
                0
              </Button>
              <Button
                className={`calculator-button ${buttonVariants.number} rounded-lg h-14 text-xl font-semibold`}
                onClick={handleDecimal}
                data-testid="button-decimal"
              >
                .
              </Button>
            </div>

            {/* Error Display */}
            <div 
              className={`mt-4 text-destructive text-center font-medium transition-opacity duration-300 ${
                showError ? "opacity-100" : "opacity-0"
              }`}
              data-testid="text-error"
            >
              خطأ في العملية الحسابية
            </div>
          </div>
        </Card>

        {/* Keyboard Hint */}
        <div className="mt-6 text-center text-muted-foreground text-sm">
          <p>يمكنك استخدام لوحة المفاتيح للإدخال</p>
          <p className="mt-1">اضغط Enter للحساب • Escape للمسح</p>
        </div>
      </div>
    </div>
  );
}
